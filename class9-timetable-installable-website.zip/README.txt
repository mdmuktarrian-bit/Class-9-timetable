CLASS 9 TIMETABLE PWA

This is a simple installable website (PWA). It is not yet published online.

PUBLISH FREE WITH GITHUB PAGES:
1. Sign in to GitHub and create a PUBLIC repository, e.g. class9-timetable.
2. Upload all files from this folder directly into the repository root.
3. Open repository Settings -> Pages.
4. Under Build and deployment choose Deploy from a branch.
5. Choose branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish your site. The URL will appear in Settings -> Pages.

INSTALL ON ANDROID:
1. Open the published HTTPS website in Chrome.
2. Open the browser menu (three dots).
3. Tap Install app or Add to Home screen, then confirm.
The install button inside the website may also appear when supported.

NOTES:
- This is a sample timetable. Change times/subjects to match your actual school.
- A public website is visible to anyone who has the link.
